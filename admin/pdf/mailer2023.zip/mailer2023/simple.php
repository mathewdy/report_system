<?php
include('smtp/PHPMailerAutoload.php');
echo smtp_mailer('sender_mailer_id(jisko mail send krna hai vo gmail)','hello this is subject','this is message');
function smtp_mailer($to,$subject, $msg){
	$mail = new PHPMailer(); 
	//$mail->SMTPDebug=3;
	$mail->IsSMTP(); 
	$mail->SMTPAuth = true; 
	$mail->SMTPSecure = 'ssl'; 
	// $mail->Host = "smtp.hostinger.com";
	$mail->Host = "Enter Your host";
	$mail->Port = "465"; 
	$mail->IsHTML(true);
	$mail->CharSet = 'UTF-8';
	$mail->Username = "Enter Email sender gmail";
	$mail->Password = 'Enter Password whose send gmail';
	$mail->SetFrom("Enter Email sender gmail");
	$mail->Subject = $subject;
	$mail->Body =$msg;
	$mail->AddAddress($to);
	$mail->SMTPOptions=array('ssl'=>array(
		'verify_peer'=>false,
		'verify_peer_name'=>false,
		'allow_self_signed'=>false
	));
	if(!$mail->Send()){
		echo $mail->ErrorInfo;
	}else{
		echo 'Sent';
	}
}

?>
