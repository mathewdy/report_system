$(window).on('load', function() {
    $('body').removeClass('d-none');
    $('.preload-wrapper').fadeOut(1000);
})
