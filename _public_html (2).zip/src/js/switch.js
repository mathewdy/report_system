  $('#constraint_checkbox').on('change', function(event, state) {
  var status = $(".switch").prop('disabled');
            $(".switch").prop('disabled', !status);
  });
          
           


           