<?php
$conn = new mysqli("localhost", "u514457298_dilg_system" , "mathewPOGI!@#123", "u514457298_dilg_report");
if($conn == false) {
    echo "error" . $conn->error;
}

// $conn = new mysqli("localhost", "u116389031_dilg_ccc" , "mathewPOGI123", "u116389031_dilg_ccc123");
// if($conn == false) {
//     echo "error" . $conn->error;
// }
?>