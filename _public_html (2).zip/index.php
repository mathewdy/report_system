<script>
    window.location.href='users/login.php';
</script>